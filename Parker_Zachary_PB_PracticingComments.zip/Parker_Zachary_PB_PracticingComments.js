// this variable is an integar and will keep track of likes 
var likeCount = 0;
/* the purpose of this code block is to call the function increaseLikes()
using it in other parts of a larger function*/
function increaseLikes() {
    /* this is used so everytime this function is called it increases the
value stored in likeCount*/
    likeCount = likeCount + 1;
}
