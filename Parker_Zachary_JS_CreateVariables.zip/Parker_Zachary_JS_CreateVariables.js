var rHeight;//rider height,designate height with an input statement
var rAge;// rider Age, designate age with an input statement
/* using a if else statement, capture user input and 
use a comparator operator to make sure rAge is > 10 and 
rHeight > 42 inches*/